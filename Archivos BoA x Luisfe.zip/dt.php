<?php
//PIERO
$apibot = "6251353456:AAG8G-ErU243kKTzKqz80OFc9Zylfnwcj9w";

$canal = "@masterharke";
$nombrearchivo="passkclav";
?>